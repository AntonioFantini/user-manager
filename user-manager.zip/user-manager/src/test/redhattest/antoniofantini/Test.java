package redhattest.antoniofantini;

public class Test {

	@org.junit.Test
	public void test(){
		System.out.println("Testing is working");
	}
}
